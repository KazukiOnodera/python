# -*- coding: utf-8 -*-
#
#   Titanic_Beginner_1.py - 
#       TitanicデータをRandomforestで処理する
#
#   次のサイトを参考に記述
#   https://github.com/Tsunehiko511/kaggle/tree/master/titanic
#
#   auther: r.kato :2016/6/13
#   last update    :2016/6/13
#  
###################################################################################################################

###################################################################################################################
#   環境設定
###################################################################################################################
####ライブラリ
import os, csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
import warnings;
with warnings.catch_warnings():
    warnings.simplefilter("ignore"); 
    import matplotlib.pyplot as plt

###matplotlibのスタイルをggplot2にする
plt.style.use('ggplot')

###ディレクトリ
data_dir = "/home/ryo/OneDrive/ドキュメント/01Analytics/10Competition/Titanic/Data"
submit_dir = "/home/ryo/OneDrive/ドキュメント/01Analytics/10Competition/Titanic/Submit"

###################################################################################################################
#   関数
###################################################################################################################
####データ加工
def df_cleaner(df):
    # 足りない部分は補おう
    # 年齢
    median_age = np.median(df[(df['Age'].notnull())]['Age'])
    for passenger in df[(df['Age'].isnull())].index: #.index = 配列内のnullの場所
        df.loc[passenger, 'Age'] = median_age
    # fare
    median_fare = np.median(df[(df['Fare'].notnull())]['Fare'])
    for passenger in df[(df['Fare'].isnull())].index:
        df.loc[passenger, 'Fare'] = median_fare

    # 文字列データを数値データへ
    df.loc[(df['Sex'] == 'male'),'Sex'] = 0
    df.loc[(df['Sex'] == 'female'),'Sex'] = 1
    df.loc[(df['Sex'].isnull()),'Sex'] = 2
    df.loc[(df['Embarked'] == 'S'),'Embarked'] = 0
    df.loc[(df['Embarked'] == 'C'),'Embarked'] = 1
    df.loc[(df['Embarked'] == 'Q'),'Embarked'] = 2
    df.loc[(df['Embarked'].isnull()),'Embarked'] = 3

    return df

#### 作ったモデルの性能を調べる
def getScore(answer, predicts):
    sum_p = 0.0
    total = 0.0
    for (row, predict) in zip(answer,predicts):
        if row == predict:
            sum_p += 1.0
        total += 1.0
    return sum_p/total

###################################################################################################################
#   モデル構築
###################################################################################################################
####データ読込
#★自前のディレクトリに変更
os.chdir(data_dir)  

#csvデータ読込み
train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")

####データの情報を確認
#trainデータ
train.info()
train.describe()
train.head()

#testデータ
test.info()
test.describe()
test.head()

####データ加工
# とりあえず不要な項目を消去
train.drop(['Name', 'PassengerId', 'Ticket', 'Cabin'], axis=1, inplace=True)
test.drop(['Name', 'Ticket', 'Cabin'], axis=1, inplace=True)

#数量化してモデル構築用データにする
train = df_cleaner(train)
test = df_cleaner(test)

x_train = train[:][['Pclass', 'Sex','Age', 'SibSp', 'Parch', 'Fare', 'Embarked']]
y_train = train[:][['Survived']]

####ランダムフォレストによるモデル構築
scores =[]
for trees in range(1,100):
    model = RandomForestClassifier(n_estimators=trees)
    model.fit(x_train, np.ravel(y_train))
    # 一致率を見よう
    pre = model.predict(x_train)
    scores.append(getScore(y_train['Survived'],pre))
plt.plot(scores,'-r')
plt.xlabel("trees") 
plt.ylabel("scores")
plt.show()

####Plot Importance
feature_importance = model.feature_importances_
imp_1 = pd.DataFrame({"features":['Pclass', 'Sex','Age', 'SibSp', 'Parch', 'Fare', 'Embarked'],
                      "importance":feature_importance})
imp_1 = imp_1.sort_values(by="importance",ascending=True)
imp_1.plot(kind='barh', x='features', y='importance', legend=False, figsize=(12, 10), color="blue")

####構築したモデルで予測
#テストデータ加工
x_test = test[:][['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']]
label = test[:][['PassengerId']]

#modelを使って予測
output = model.predict(x_test)

####サブミットファイルを作成 
submit_df = pd.DataFrame({"PassengerId":label['PassengerId'], "Survived":output.astype(int)})
os.chdir(submit_dir)
submit_df.to_csv("titanic_submitfile_1", index=False)

###################################################################################################################
#   EoF
###################################################################################################################
